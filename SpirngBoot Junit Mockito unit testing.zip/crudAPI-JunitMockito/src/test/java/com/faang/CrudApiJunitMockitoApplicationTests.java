package com.faang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApiJunitMockitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
