package com.faang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApiJunitMockitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApiJunitMockitoApplication.class, args);
	}

}
